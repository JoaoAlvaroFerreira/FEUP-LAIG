/**
 * Animation
 * @constructor
 */

class Animation
{
	constructor()
	{

    };
    applyMatrix(){};
};
